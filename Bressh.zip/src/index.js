import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  Client,
  Collection,
  Events,
  GatewayIntentBits,
  Partials,
  PermissionsBitField,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
} from 'discord.js';
import { commandBuilders } from './commands.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const configPath = path.resolve(__dirname, '../data/config.json');
const cookieLocksPath = path.resolve(__dirname, '../data/cookie-locks');
const { DISCORD_TOKEN } = process.env;

if (!DISCORD_TOKEN) {
  throw new Error('Falta DISCORD_TOKEN en el archivo .env');
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  partials: [Partials.GuildMember, Partials.Message],
});
const commands = new Collection(commandBuilders.map((builder) => [builder.name, builder]));
const activeCookieGames = new Set();
const finishedCookieGames = new Set();
const activeGiveaways = new Map();
const activeRandomButtons = new Map();
const pendingSocialInteractions = new Map();
const afkUsers = new Map();
const logChannelIds = new Map();
const raidJoinTimes = new Map();
const repeatedMessages = new Map();
const socialInteractionImages = {
  kiss: 'https://vantarmor-fwtvihev.manus.space/manus-storage/async-images/rt7ZXPpZWjsqlgHPOomA2H/image-1.webp',
  slap: 'https://vantarmor-fwtvihev.manus.space/manus-storage/async-images/rt7ZXPpZWjsqlgHPOomA2H/image-2.webp',
};

async function readConfig() {
  try {
    return JSON.parse(await fs.readFile(configPath, 'utf8'));
  } catch {
    return {};
  }
}

async function writeConfig(config) {
  await fs.writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, 'utf8');
}

function antiRaidConfig(config, guildId) {
  return config[guildId] || {};
}

const inappropriateLanguage = [
  'gay', 'verga', 'vrg', 'down', 'dawn', 'rapa tu madre', 'raspa tu madre',
  'mmgv', 'mamaguevaso', 'mamaguevazo', 'tu puta madre', 'hijo de puta', 'perra',
];

function findInappropriateLanguage(content) {
  const normalized = content.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\W_]+/g, ' ').trim();
  return inappropriateLanguage.find((phrase) => {
    const normalizedPhrase = phrase.replace(/[\W_]+/g, ' ').trim();
    return normalized === normalizedPhrase || normalized.includes(` ${normalizedPhrase} `)
      || normalized.startsWith(`${normalizedPhrase} `) || normalized.endsWith(` ${normalizedPhrase}`);
  }) || null;
}

async function moderateIncomingMessage(message, bypass = false) {
  if (bypass) return false;
  const config = await readConfig();
  const settings = antiRaidConfig(config, message.guild.id);
  if (!settings.antiRaid && !settings.antiLink) return false;
  const content = message.content.trim();
  const normalized = content.toLowerCase();
  const blockedWord = settings.antiRaid ? (settings.blockedWords || []).find((word) => word && normalized.includes(word)) : null;
  const inappropriateWord = settings.antiInsult ? findInappropriateLanguage(content) : null;
  const hasLink = settings.antiLink && (/https?:\/\/\S+/i.test(content) || /(?:discord\.gg|discord(?:app)?\.com\/invite)\/\S+/i.test(content));
  const key = `${message.guild.id}:${message.author.id}`;
  const previous = repeatedMessages.get(key);
  const now = Date.now();
  const repeated = previous && previous.content === normalized && now - previous.startedAt < 60_000
    ? { content: normalized, count: previous.count + 1, startedAt: previous.startedAt }
    : { content: normalized, count: 1, startedAt: now };
  repeatedMessages.set(key, repeated);
  const isRepeated = settings.antiRaid && repeated.count > 5;
  if (!blockedWord && !inappropriateWord && !hasLink && !isRepeated) return false;
  await message.delete().catch(() => null);
  const reason = inappropriateWord
    ? `lenguaje no adecuado: ${inappropriateWord}`
    : blockedWord ? `palabra bloqueada: ${blockedWord}` : hasLink ? 'enlace o invitación' : 'mensaje repetido más de 5 veces';
  queueLog(message.guild, 'Mensaje eliminado por Anti-Raid', 0xef4444, [
    { name: 'Usuario', value: `${message.author.tag} (${message.author.id})` },
    { name: 'Canal', value: `${message.channel}` },
    { name: 'Razón', value: reason },
  ]);
  return true;
}

async function logAction(guild, title, color, fields = []) {
  const channelId = logChannelIds.get(guild.id);
  if (!channelId) return;
  const channel = guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased()) return;
  await channel.send({ embeds: [new EmbedBuilder().setTitle(title).setColor(color).addFields(fields).setTimestamp()] });
}

function queueLog(guild, title, color, fields = []) {
  void logAction(guild, title, color, fields).catch((error) => console.error('No se pudo enviar un log:', error.message));
}

async function getBlacklistRole(guild, create = false) {
  const config = await readConfig();
  const savedRoleId = config[guild.id]?.blacklistRoleId;
  const savedRole = savedRoleId ? await guild.roles.fetch(savedRoleId).catch(() => null) : null;
  if (savedRole) return savedRole;
  const existingRole = guild.roles.cache.find((role) => role.name.toLowerCase() === 'blacklist');
  if (existingRole || !create) return existingRole || null;
  const role = await guild.roles.create({ name: 'Blacklist', color: '#159bd3', reason: 'Bressh.bot: rol de lista negra' });
  config[guild.id] = { ...(config[guild.id] || {}), blacklistRoleId: role.id };
  await writeConfig(config);
  return role;
}

const blacklistPermissions = {
  ViewChannel: false,
  SendMessages: false,
  AddReactions: false,
  Connect: false,
  Speak: false,
  SendMessagesInThreads: false,
  CreatePublicThreads: false,
  CreatePrivateThreads: false,
  UseApplicationCommands: false,
};

async function applyBlacklist(guild, member, role, blocked) {
  if (blocked) await member.roles.add(role, 'Bressh.bot: miembro añadido a la blacklist');
  else await member.roles.remove(role, 'Bressh.bot: miembro retirado de la blacklist');
  const editableChannels = guild.channels.cache.filter((channel) => channel.permissionOverwrites?.edit);
  void Promise.all(editableChannels.map((channel) => channel.permissionOverwrites.edit(member, blocked ? blacklistPermissions : {
    ViewChannel: null,
    SendMessages: null,
    AddReactions: null,
    Connect: null,
    Speak: null,
    SendMessagesInThreads: null,
    CreatePublicThreads: null,
    CreatePrivateThreads: null,
    UseApplicationCommands: null,
  }, { reason: `Bressh.bot: ${blocked ? 'blacklist' : 'unblacklist'}` }).catch(() => null))).catch((error) => console.error('No se pudieron actualizar todos los canales de blacklist:', error.message));
}

function canManageRole(guild, role) {
  const me = guild.members.me;
  return Boolean(me && role.editable && role.position < me.roles.highest.position && !role.managed);
}

function replyError(interaction, message) {
  const payload = { content: `No puedo completar la acción: ${message}`, ephemeral: true };
  return interaction.deferred ? interaction.editReply(payload) : interaction.reply(payload);
}

function afkKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

function afkReason(reason) {
  return reason?.trim() || 'no hay ningún motivo';
}

function elapsedTime(startedAt) {
  const totalMinutes = Math.max(1, Math.floor((Date.now() - startedAt) / 60_000));
  if (totalMinutes < 60) return `${totalMinutes} minuto(s)`;
  const hours = Math.floor(totalMinutes / 60);
  return `${hours} hora(s) y ${totalMinutes % 60} minuto(s)`;
}

function limitText(value, limit = 1024) {
  const text = value || 'Ninguno';
  return text.length > limit ? `${text.slice(0, limit - 3)}...` : text;
}

function userInfoEmbed(member) {
  const roles = member.roles.cache.filter((role) => role.id !== member.guild.id).sort((a, b) => b.position - a.position).map((role) => `<@&${role.id}>`);
  const status = member.presence?.status || 'no disponible';
  return new EmbedBuilder()
    .setColor(0x20b8e8)
    .setTitle(`Información de ${member.user.tag}`)
    .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
    .addFields(
      { name: 'Usuario', value: `${member} | ${member.user.tag}`, inline: false },
      { name: 'ID', value: member.id, inline: true },
      { name: 'Bot', value: member.user.bot ? 'Sí' : 'No', inline: true },
      { name: 'Cuenta creada', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:F>`, inline: false },
      { name: 'Entrada al servidor', value: member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>` : 'No disponible', inline: false },
      { name: 'Apodo', value: member.nickname || 'Sin apodo', inline: true },
      { name: 'Estado', value: status, inline: true },
      { name: `Roles (${roles.length})`, value: limitText(roles.join(' ') || 'Sin roles adicionales'), inline: false },
    )
    .setFooter({ text: 'Bressh.bot • información del miembro' })
    .setTimestamp();
}

async function avatarEmbed(user, random = false) {
  const profile = await user.fetch().catch(() => user);
  const png = profile.displayAvatarURL({ extension: 'png', size: 1024, forceStatic: true });
  const jpg = profile.displayAvatarURL({ extension: 'jpg', size: 1024, forceStatic: true });
  const webp = profile.displayAvatarURL({ extension: 'webp', size: 1024, forceStatic: true });
  const bannerPng = profile.bannerURL?.({ extension: 'png', size: 1024, forceStatic: true }) || null;
  const bannerJpg = profile.bannerURL?.({ extension: 'jpg', size: 1024, forceStatic: true }) || null;
  const bannerWebp = profile.bannerURL?.({ extension: 'webp', size: 1024, forceStatic: true }) || null;
  const embed = new EmbedBuilder()
    .setColor(0x20b8e8)
    .setTitle(`Perfil visual de ${profile.tag}`)
    .setThumbnail(png)
    .addFields({ name: 'Avatar', value: `[PNG](${png}) • [JPG](${jpg}) • [WEBP](${webp})` })
    .setFooter({ text: random ? 'Bressh.bot • miembro elegido al azar' : 'Bressh.bot • avatar y banner' });
  if (bannerPng) {
    embed.setImage(bannerPng);
    embed.addFields({ name: 'Banner', value: `[PNG](${bannerPng}) • [JPG](${bannerJpg}) • [WEBP](${bannerWebp})` });
  } else {
    embed.addFields({ name: 'Banner', value: 'Este usuario no tiene un banner configurado.' });
  }
  return embed;
}

async function serverInfoEmbed(guild) {
  const owner = await guild.fetchOwner().catch(() => null);
  const verification = ['Ninguna', 'Baja', 'Media', 'Alta', 'Muy alta'][guild.verificationLevel] || 'Desconocida';
  const roles = guild.roles.cache.filter((role) => role.id !== guild.id).sort((a, b) => b.position - a.position).map((role) => `<@&${role.id}>`);
  const channels = guild.channels.cache;
  const textChannels = channels.filter((channel) => channel.isTextBased() && !channel.isVoiceBased()).size;
  const voiceChannels = channels.filter((channel) => channel.isVoiceBased()).size;
  const categories = channels.filter((channel) => channel.type === ChannelType.GuildCategory).size;
  const embed = new EmbedBuilder()
    .setColor(0x063b5c)
    .setTitle(`Información de ${guild.name}`)
    .addFields(
      { name: 'ID', value: guild.id, inline: true },
      { name: 'Dueño', value: owner ? `${owner.user.tag} (<@${owner.id}>)` : `<@${guild.ownerId}>`, inline: true },
      { name: 'Miembros', value: String(guild.memberCount), inline: true },
      { name: 'Creado', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: false },
      { name: 'Verificación', value: verification, inline: true },
      { name: 'Canales', value: `Texto: **${textChannels}**\nVoz: **${voiceChannels}**\nCategorías: **${categories}**`, inline: true },
      { name: `Roles (${roles.length})`, value: limitText(roles.join(' ') || 'Sin roles adicionales'), inline: false },
      { name: 'Boosts', value: `${guild.premiumSubscriptionCount || 0} | Nivel ${guild.premiumTier}`, inline: true },
    )
    .setFooter({ text: 'Bressh.bot • información del servidor' })
    .setTimestamp();
  const icon = guild.iconURL({ size: 256 });
  if (icon) embed.setThumbnail(icon);
  return embed;
}

async function saveAfkState(guildId, userId, state) {
  const config = await readConfig();
  config[guildId] = { ...(config[guildId] || {}), afk: { ...(config[guildId]?.afk || {}) } };
  if (state) config[guildId].afk[userId] = state;
  else delete config[guildId].afk[userId];
  await writeConfig(config);
}

async function addWarning(guildId, userId, threshold, action, reason) {
  const config = await readConfig();
  const guildConfig = config[guildId] || {};
  const warnings = { ...(guildConfig.warnings || {}) };
  const current = Number(warnings[userId]?.count || 0) + 1;
  warnings[userId] = { count: current, threshold, action, lastReason: reason, updatedAt: Date.now() };
  config[guildId] = { ...guildConfig, warnings };
  await writeConfig(config);
  return current;
}

async function clearWarnings(guildId, userId) {
  const config = await readConfig();
  if (!config[guildId]?.warnings?.[userId]) return;
  delete config[guildId].warnings[userId];
  await writeConfig(config);
}

async function applyWarningAction(guild, member, action, reason) {
  if (action === 'ban') {
    if (!member.bannable) throw new Error('mi rango no puede banear a ese miembro.');
    await guild.members.ban(member.id, { reason });
    return 'baneado';
  }
  if (action === 'kick') {
    if (!member.kickable) throw new Error('mi rango no puede expulsar a ese miembro.');
    await member.kick(reason);
    return 'expulsado';
  }
  if (action === 'silence') {
    if (!member.moderatable) throw new Error('mi rango no puede silenciar a ese miembro.');
    await member.timeout(10 * 60 * 1000, reason);
    return 'silenciado durante 10 minutos';
  }
  if (action === 'blacklist') {
    const botMember = guild.members.me;
    if (!botMember?.permissions.has(PermissionsBitField.Flags.ManageRoles) || !botMember.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      throw new Error('Bressh.bot necesita Manage Roles y Manage Channels para aplicar blacklist.');
    }
    const role = await getBlacklistRole(guild, true);
    if (!role) throw new Error('no se pudo crear o encontrar el rol Blacklist.');
    await applyBlacklist(guild, member, role, true);
    return 'añadido a blacklist';
  }
  throw new Error('acción de advertencia no válida.');
}

const warningActionLabels = { ban: 'ban', silence: 'silenciar 10 minutos', kick: 'expulsar', blacklist: 'blacklist' };

async function setChannelLock(channel, locked, actorTag) {
  const everyone = channel.guild.roles.everyone;
  await channel.permissionOverwrites.edit(everyone, { SendMessages: locked ? false : null }, { reason: `Bressh.bot por ${actorTag}` });
}

async function purgeMessages(channel, amount, excludedIds = new Set(), authorId = null) {
  if (!channel.isTextBased() || typeof channel.bulkDelete !== 'function') throw new Error('Este canal no permite borrar mensajes en bloque.');
  const cutoff = Date.now() - 14 * 24 * 60 * 60 * 1000;
  let deletedTotal = 0;
  let before;
  while (deletedTotal < amount) {
    const messages = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) });
    if (!messages.size) break;
    const eligible = messages.filter((message) => !excludedIds.has(message.id)
      && (!authorId || message.author?.id === authorId)
      && message.createdTimestamp >= cutoff);
    const batch = eligible.first(Math.min(100, amount - deletedTotal));
    if (batch.length) {
      const deleted = await channel.bulkDelete(batch, true);
      deletedTotal += deleted.size;
    }
    const oldest = messages.last();
    if (!oldest || oldest.createdTimestamp < cutoff) break;
    before = oldest.id;
  }
  return deletedTotal;
}

function ticketSettings(config, guildId) {
  return config[guildId]?.ticket || { staffRoleIds: [] };
}

function ticketButtonRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_open').setLabel('📩 Abrir ticket').setStyle(ButtonStyle.Success),
  );
}

function ticketCloseRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Cerrar ticket').setStyle(ButtonStyle.Danger),
  );
}

function randomButtonRow(messageId, disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`random_button:${messageId}`)
      .setLabel(disabled ? 'Resultado revelado' : '🎉 Presionar botón')
      .setStyle(disabled ? ButtonStyle.Secondary : ButtonStyle.Primary)
      .setDisabled(disabled),
  );
}

function randomButtonResult(message, userId) {
  const mention = `<@${userId}>`;
  if (!message) return `${mention} lamentablemente la respuesta es **${Math.random() < 0.5 ? 'sí' : 'no'}**.`;
  const positive = Math.random() < 0.5;
  const match = message.trim().match(/^(?:te|me|le)\s+(gusta|gustan)\s+(.+)$/i);
  if (match) {
    const verb = match[1].toLowerCase();
    const subject = match[2].trim().replace(/[.!?]+$/, '');
    return `${mention} lamentablemente ${positive ? 'sí' : 'no'} le ${verb} ${subject}.`;
  }
  return `${mention} lamentablemente la respuesta es **${positive ? 'sí' : 'no'}**: ${message}`;
}

function socialInteractionEmbed(type, actor, target) {
  const isKiss = type === 'kiss';
  return new EmbedBuilder()
    .setColor(isKiss ? 0xec4899 : 0xf59e0b)
    .setDescription(`${actor} acaba de ${isKiss ? 'besar' : 'abofetear'} a ${target}.`)
    .setImage(socialInteractionImages[type])
    .setFooter({ text: `Bressh.bot • interacción de ${isKiss ? 'beso' : 'bofetada'}` });
}

function socialInteractionRow(type, messageId, disabled = false) {
  const button = type === 'kiss'
    ? new ButtonBuilder().setCustomId(`kiss_accept:${messageId}`).setLabel('Coincidir').setStyle(ButtonStyle.Success).setDisabled(disabled)
    : new ButtonBuilder().setCustomId(`slap_return:${messageId}`).setLabel('🟨 Devolver').setStyle(ButtonStyle.Secondary).setDisabled(disabled);
  if (type === 'kiss') {
    return new ActionRowBuilder().addComponents(
      button,
      new ButtonBuilder().setCustomId(`kiss_reject:${messageId}`).setLabel('Rechazar').setStyle(ButtonStyle.Danger).setDisabled(disabled),
    );
  }
  return new ActionRowBuilder().addComponents(button);
}

function socialInteractionResult(type, interaction, data, accepted) {
  if (type === 'kiss') return accepted
    ? `<@${data.targetId}> coincidió con el beso de <@${data.actorId}>. 💚`
    : `<@${data.targetId}> rechazó el beso de <@${data.actorId}>. ❌`;
  return `<@${data.targetId}> le devolvió la bofetada a <@${data.actorId}>. 👋`;
}

async function publishSocialInteraction(channel, type, actor, target) {
  const sent = await channel.send({ embeds: [socialInteractionEmbed(type, actor, target)] });
  pendingSocialInteractions.set(sent.id, { type, actorId: actor.id, targetId: target.id });
  await sent.edit({ components: [socialInteractionRow(type, sent.id)] });
  return sent;
}

function ticketPanelEmbed(message) {
  return new EmbedBuilder()
    .setColor(0x20b8e8)
    .setTitle('Soporte')
    .setDescription(message)
    .setFooter({ text: 'Bressh.bot • sistema de tickets' });
}

function ticketEmbed(user) {
  return new EmbedBuilder()
    .setColor(0x20b8e8)
    .setTitle('Ticket abierto')
    .setDescription(`Hola ${user}, explica tu problema con detalle. El equipo de soporte te atenderá aquí.`)
    .setFooter({ text: 'Bressh.bot • soporte privado' });
}

function ticketChannelName(user) {
  const safeName = user.username.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 35) || 'usuario';
  return `ticket-${safeName}-${user.id.slice(-5)}`.slice(0, 100);
}

function isTicketStaff(member, settings) {
  return member.permissions.has(PermissionsBitField.Flags.ManageChannels)
    || (settings.staffRoleIds || []).some((roleId) => member.roles.cache.has(roleId));
}

async function ticketLog(guild, settings, title, fields) {
  if (!settings.ticketLogChannelId) return;
  const channel = guild.channels.cache.get(settings.ticketLogChannelId) || await guild.channels.fetch(settings.ticketLogChannelId).catch(() => null);
  if (!channel?.isTextBased()) return;
  await channel.send({ embeds: [new EmbedBuilder().setTitle(title).setColor(0x20b8e8).addFields(fields).setTimestamp()] }).catch(() => null);
}

async function createTicketChannel(guild, user, settings) {
  const existing = guild.channels.cache.find((channel) => channel.type === ChannelType.GuildText && channel.topic === `bressh-ticket:${user.id}`);
  if (existing) return { existing };
  const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
  if (!me) throw new Error('no pude encontrar al miembro de Bressh.bot en el servidor.');
  const staffRoleIds = (settings.staffRoleIds || []).filter((roleId) => guild.roles.cache.has(roleId));
  const permissionOverwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
    { id: user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory, PermissionsBitField.Flags.AttachFiles] },
    { id: me.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory, PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.ManageMessages] },
    ...staffRoleIds.map((roleId) => ({ id: roleId, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] })),
  ];
  const channel = await guild.channels.create({
    name: ticketChannelName(user),
    type: ChannelType.GuildText,
    parent: settings.categoryId,
    topic: `bressh-ticket:${user.id}`,
    permissionOverwrites,
    reason: `Bressh.bot: ticket abierto por ${user.tag}`,
  });
  const staffMentions = staffRoleIds.map((roleId) => `<@&${roleId}>`).join(' ');
  await channel.send({ content: `${user} ${staffMentions}`.trim(), embeds: [ticketEmbed(user)], components: [ticketCloseRow()] });
  return { channel };
}

const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));

async function claimCookieGame(messageId) {
  await fs.mkdir(cookieLocksPath, { recursive: true });
  const lockPath = path.join(cookieLocksPath, `${messageId}.lock`);
  try {
    const handle = await fs.open(lockPath, 'wx');
    await handle.writeFile(`pending:${Date.now()}`);
    await handle.close();
    return { claimed: true, lockPath };
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
    const lockContents = await fs.readFile(lockPath, 'utf8').catch(() => '');
    if (lockContents.startsWith('finished:')) return { claimed: false, lockPath, finished: true };
    const stats = await fs.stat(lockPath).catch(() => null);
    if (stats && Date.now() - stats.mtimeMs > 60_000) {
      await fs.unlink(lockPath).catch(() => null);
      return claimCookieGame(messageId);
    }
    return { claimed: false, lockPath };
  }
}

async function finishCookieGame(lockPath, userId) {
  await fs.writeFile(lockPath, `finished:${userId}`, 'utf8').catch(() => null);
}

function cookieRow({ disabled = false, winner = false } = {}) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('cookie_game_button')
      .setLabel(winner ? 'Ganador' : '🍪')
      .setStyle(winner ? ButtonStyle.Success : ButtonStyle.Primary)
      .setDisabled(disabled),
  );
}

function parseGiveawayDuration(input) {
  const value = (input || '1h').trim().toLowerCase();
  const match = value.match(/^(\d+)(m|h|d)$/);
  if (!match) return null;
  const amount = Number(match[1]);
  const milliseconds = amount * ({ m: 60_000, h: 3_600_000, d: 86_400_000 }[match[2]]);
  if (!Number.isSafeInteger(milliseconds) || milliseconds < 60_000 || milliseconds > 20 * 86_400_000) return null;
  return { milliseconds, label: `${amount}${match[2]}` };
}

function giveawayRow(messageId, disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`giveaway_join:${messageId}`)
      .setLabel(disabled ? 'Sorteo finalizado' : 'Participar')
      .setStyle(disabled ? ButtonStyle.Secondary : ButtonStyle.Primary)
      .setDisabled(disabled),
  );
}

function giveawayEmbed(giveaway, winners = null) {
  const ended = winners !== null;
  const description = ended
    ? (winners.length ? `Ganador(es): ${winners.map((id) => `<@${id}>`).join(', ')}` : 'No hubo participantes.')
    : `Pulsa **Participar** para entrar.\nTermina: <t:${Math.floor(giveaway.endsAt / 1000)}:R>`;
  return new EmbedBuilder()
    .setColor(ended ? 0x64748b : 0x20b8e8)
    .setTitle(ended ? '🎉 Sorteo finalizado' : '🎉 Sorteo')
    .setDescription(description)
    .addFields(
      { name: 'Recompensa', value: giveaway.reward },
      { name: 'Ganadores', value: String(giveaway.winnerLimit), inline: true },
      { name: 'Participantes', value: String(giveaway.participants.size), inline: true },
    )
    .setFooter({ text: 'Bressh.bot • sorteos' });
}

async function finishGiveaway(messageId) {
  const giveaway = activeGiveaways.get(messageId);
  if (!giveaway) return;
  activeGiveaways.delete(messageId);
  const guild = client.guilds.cache.get(giveaway.guildId);
  const members = guild ? await Promise.all([...giveaway.participants].map((userId) => guild.members.fetch(userId).catch(() => null))) : [];
  const ids = members.filter((member) => member && !member.user.bot).map((member) => member.id);
  for (let index = ids.length - 1; index > 0; index -= 1) {
    const randomIndex = Math.floor(Math.random() * (index + 1));
    [ids[index], ids[randomIndex]] = [ids[randomIndex], ids[index]];
  }
  const winners = ids.slice(0, giveaway.winnerLimit);
  const channel = guild?.channels.cache.get(giveaway.channelId);
  const message = channel?.isTextBased() ? await channel.messages.fetch(messageId).catch(() => null) : null;
  if (message) {
    await message.edit({ embeds: [giveawayEmbed(giveaway, winners)], components: [giveawayRow(messageId, true)] }).catch(() => null);
    await channel.send(winners.length
      ? `🎉 El sorteo terminó. Ganador(es) de **${giveaway.reward}**: ${winners.map((id) => `<@${id}>`).join(', ')}`
      : `El sorteo de **${giveaway.reward}** terminó sin participantes.`).catch(() => null);
  }
}

client.once(Events.ClientReady, (readyClient) => {
  console.log(`Bressh.bot conectado como ${readyClient.user.tag}`);
  console.log(`Servidores activos: ${readyClient.guilds.cache.size}`);
  readConfig().then((config) => {
    for (const [guildId, guildConfig] of Object.entries(config)) {
      for (const [userId, state] of Object.entries(guildConfig.afk || {})) afkUsers.set(afkKey(guildId, userId), state);
      if (guildConfig.logChannelId) logChannelIds.set(guildId, guildConfig.logChannelId);
    }
  }).catch((error) => console.error('No se pudo cargar AFK:', error));
});

client.on(Events.GuildMemberAdd, async (member) => {
  const config = await readConfig();
  const welcome = config[member.guild.id]?.welcome;
  if (config[member.guild.id]?.antiRaid && !member.user.bot) {
    const now = Date.now();
    const recentJoins = (raidJoinTimes.get(member.guild.id) || []).filter((timestamp) => now - timestamp < 20_000);
    recentJoins.push(now);
    raidJoinTimes.set(member.guild.id, recentJoins);
    if (recentJoins.length >= 6 && member.kickable) {
      await member.kick('Bressh.bot Anti-Raid: entrada masiva sospechosa').catch(() => null);
      queueLog(member.guild, 'Miembro expulsado por Anti-Raid', 0xdc2626, [
        { name: 'Usuario', value: `${member.user.tag} (${member.id})` },
        { name: 'Entradas recientes', value: String(recentJoins.length) },
      ]);
      return;
    }
  }
  if (welcome?.channelId && welcome.message) {
    const channel = await member.guild.channels.fetch(welcome.channelId).catch(() => null);
    if (channel?.isTextBased()) {
      const mention = `<@${member.id}>`;
      const text = welcome.message.replaceAll('{usuario}', mention);
      const content = `${welcome.sign || ''}${mention} ${text}${welcome.emoji ? ` ${welcome.emoji}` : ''}`.trim();
      const embed = new EmbedBuilder()
        .setColor(welcome.image ? 0x20b8e8 : 0x050505)
        .setTitle('👋 Bienvenido')
        .setDescription(content)
        .setFooter({ text: 'Bressh.bot • mensaje de bienvenida' })
        .setTimestamp();
      if (welcome.image) embed.setThumbnail(member.displayAvatarURL({ size: 256 }));
      await channel.send({ embeds: [embed] }).catch((error) => console.error('No se pudo enviar bienvenida:', error.message));
    }
  }
  const roleId = config[member.guild.id]?.autorolId;
  if (!roleId) return;

  const role = await member.guild.roles.fetch(roleId).catch(() => null);
  if (!role || !canManageRole(member.guild, role)) return;
  await member.roles.add(role, 'Bressh.bot: rol automático para nuevo miembro').catch((error) => console.error('No se pudo asignar autorol:', error.message));
});

client.on(Events.MessageCreate, async (message) => {
  const command = message.content.trim().toLowerCase();
  if (message.author.bot || !message.guild) return;
  if (await moderateIncomingMessage(message, message.author.id === message.guild.ownerId)) return;

  if (command === '?avatar') {
    const referenced = message.reference?.messageId ? await message.fetchReference().catch(() => null) : null;
    const targetUser = referenced?.author || message.author;
    await message.reply({ embeds: [await avatarEmbed(targetUser)] });
    return;
  }

  if (command === '?kiss' || command === '?slap') {
    const referenced = message.reference?.messageId ? await message.fetchReference().catch(() => null) : null;
    if (!referenced?.author) {
      await message.reply(`Responde al mensaje de un usuario y usa ${command}.`);
      return;
    }
    await publishSocialInteraction(message.channel, command.slice(1), message.author, referenced.author);
    return;
  }

  if (command.startsWith('?afk')) {
    const state = { since: Date.now(), reason: afkReason(message.content.trim().slice(4)) };
    afkUsers.set(afkKey(message.guild.id, message.author.id), state);
    void saveAfkState(message.guild.id, message.author.id, state).catch((error) => console.error('No se pudo guardar AFK:', error.message));
    await message.reply(`<@${message.author.id}> ahora está afk.\nMotivo: ${state.reason}`);
    return;
  }

  if (command.startsWith('?warn')) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
      await message.reply('No puedo hacerlo: necesitas el permiso **Moderate Members**.');
      return;
    }
    const targetUser = message.mentions.users.first();
    const args = message.content.trim().split(/\s+/).slice(1);
    const threshold = Number.parseInt(args.find((value) => /^\d+$/.test(value)), 10);
    const action = args.map((value) => value.toLowerCase()).find((value) => ['ban', 'silence', 'kick', 'blacklist'].includes(value));
    if (!targetUser || !Number.isInteger(threshold) || threshold < 1 || threshold > 10 || !action) {
      await message.reply('Uso correcto: `?warn @usuario avisos acción motivo` — avisos: 1-10; acción: `ban`, `silence`, `kick` o `blacklist`.');
      return;
    }
    const member = await message.guild.members.fetch(targetUser.id).catch(() => null);
    if (!member) {
      await message.reply('Ese usuario no es un miembro del servidor.');
      return;
    }
    if (member.id === message.author.id) {
      await message.reply('No puedes advertirte a ti mismo.');
      return;
    }
    const reason = args.filter((value) => value !== threshold.toString() && value.toLowerCase() !== action && !value.startsWith('<@')).join(' ').trim() || `Advertencia aplicada por ${message.author.tag}`;
    try {
      const count = await addWarning(message.guild.id, member.id, threshold, action, reason);
      if (count < threshold) {
        queueLog(message.guild, 'Advertencia añadida', 0xf59e0b, [
          { name: 'Usuario', value: `${member.user.tag} (${member.id})` },
          { name: 'Moderador', value: `${message.author.tag} (${message.author.id})` },
          { name: 'Progreso', value: `${count}/${threshold}` },
          { name: 'Motivo', value: reason },
        ]);
        await message.reply(`⚠️ ${member.user.tag} recibió una advertencia (**${count}/${threshold}**). Acción al llegar al límite: **${warningActionLabels[action]}**.`);
        return;
      }
      const result = await applyWarningAction(message.guild, member, action, reason);
      await clearWarnings(message.guild.id, member.id);
      queueLog(message.guild, `Advertencias: ${result}`, 0xdc2626, [
        { name: 'Usuario', value: `${member.user.tag} (${member.id})` },
        { name: 'Moderador', value: `${message.author.tag} (${message.author.id})` },
        { name: 'Motivo', value: reason },
      ]);
      await message.reply(`⚠️ ${member.user.tag} alcanzó **${threshold}/${threshold}** advertencias y fue **${result}**.`);
    } catch (error) {
      await message.reply(`No pude aplicar la acción de warn: ${error.message}`);
    }
    return;
  }

  if (command === '?servidor') {
    await message.reply({ embeds: [await serverInfoEmbed(message.guild)] });
    return;
  }

  if (command === '?purge' || command.startsWith('?purge ')) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
      await message.reply('No puedo hacerlo: necesitas el permiso **Manage Messages**.');
      return;
    }
    const amount = Number.parseInt(message.content.trim().slice(6).trim(), 10);
    if (!Number.isInteger(amount) || amount < 1 || amount > 100) {
      await message.reply('Uso correcto: `?purge 1-100`.');
      return;
    }
    try {
      const response = await message.reply('⏳ Eliminando mensajes...');
      const deleted = await purgeMessages(message.channel, amount, new Set([response.id]));
      queueLog(message.guild, 'Mensajes eliminados', 0xef4444, [
        { name: 'Moderador', value: `${message.author.tag} (${message.author.id})` },
        { name: 'Canal', value: `${message.channel}` },
        { name: 'Cantidad', value: String(deleted) },
      ]);
      await response.edit(`🧹 Se eliminaron **${deleted}** mensaje(s).`);
    } catch (error) {
      console.error('Error en ?purge:', error);
      await message.reply('No pude borrar los mensajes. Comprueba que Bressh.bot tenga **Manage Messages**.');
    }
    return;
  }

  const ownAfkKey = afkKey(message.guild.id, message.author.id);
  const ownAfk = afkUsers.get(ownAfkKey);
  if (ownAfk) {
    afkUsers.delete(ownAfkKey);
    void saveAfkState(message.guild.id, message.author.id, null).catch((error) => console.error('No se pudo guardar el fin de AFK:', error.message));
    await message.reply(`<@${message.author.id}> salió de afk y llevaba ${elapsedTime(ownAfk.since)}.`);
  }

  for (const user of message.mentions.users.values()) {
    const state = afkUsers.get(afkKey(message.guild.id, user.id));
    if (state) await message.reply(`<@${user.id}> está afk\nMotivo: ${state.reason}`);
  }

  if (!['?lock', '?unlock'].includes(command)) return;
  if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
    await message.reply('No puedo hacerlo: necesitas el permiso **Manage Channels**.');
    return;
  }

  const locked = command === '?lock';
  const response = await message.reply(locked ? '⏳ Bloqueando canal...' : '⏳ Desbloqueando canal...');
  try {
    await setChannelLock(message.channel, locked, message.author.tag);
    await response.edit(locked ? '🔒 Canal bloqueado.' : '🔓 Canal desbloqueado.');
  } catch (error) {
    console.error(`Error en ${command}:`, error);
    await response.edit('No pude cambiar los permisos de este canal. Comprueba que Bressh.bot tenga **Manage Channels**.');
  }
});

client.on(Events.MessageDelete, (message) => {
  if (!message.guild || message.author?.bot) return;
  queueLog(message.guild, 'Mensaje eliminado', 0xef4444, [
    { name: 'Autor', value: message.author ? `${message.author.tag} (${message.author.id})` : 'Desconocido' },
    { name: 'Canal', value: `${message.channel}` },
    { name: 'Contenido', value: message.content?.slice(0, 1024) || 'No disponible' },
  ]);
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.inGuild()) return;

  if (interaction.isButton() && interaction.customId.startsWith('random_button:')) {
    const messageId = interaction.customId.slice('random_button:'.length);
    const game = activeRandomButtons.get(messageId);
    if (!game) {
      await interaction.reply({ content: 'Este botón ya no está activo.', ephemeral: true });
      return;
    }
    await interaction.reply({ content: randomButtonResult(game.message, interaction.user.id) });
    return;
  }

  if (interaction.isButton() && /^(kiss_accept|kiss_reject|slap_return):/.test(interaction.customId)) {
    const [action, messageId] = interaction.customId.split(':');
    const data = pendingSocialInteractions.get(messageId);
    if (!data) {
      await interaction.reply({ content: 'Esta interacción ya fue respondida.', ephemeral: true });
      return;
    }
    if (interaction.user.id !== data.targetId) {
      await interaction.reply({ content: 'Solo la persona mencionada puede usar este botón.', ephemeral: true });
      return;
    }
    pendingSocialInteractions.delete(messageId);
    const accepted = action === 'kiss_accept' || action === 'slap_return';
    await interaction.update({
      content: socialInteractionResult(data.type, interaction, data, accepted),
      components: [socialInteractionRow(data.type, messageId, true)],
    });
    return;
  }

  if (interaction.isButton() && interaction.customId === 'ticket_open') {
    await interaction.deferReply({ ephemeral: true });
    const config = await readConfig();
    const settings = ticketSettings(config, interaction.guild.id);
    if (!settings.categoryId) return interaction.editReply({ content: 'El sistema de tickets aún no tiene una categoría configurada. Usa `/ticketperm categoria`.' });
    if (!settings.staffRoleIds?.length) return interaction.editReply({ content: 'El sistema de tickets aún no tiene un rol de soporte configurado. Usa `/ticketperm agregar-rol`.' });
    try {
      const result = await createTicketChannel(interaction.guild, interaction.user, settings);
      if (result.existing) return interaction.editReply({ content: `Ya tienes un ticket abierto: ${result.existing}` });
      await ticketLog(interaction.guild, settings, 'Ticket abierto', [
        { name: 'Usuario', value: `${interaction.user.tag} (${interaction.user.id})` },
        { name: 'Canal', value: `${result.channel}` },
      ]);
      return interaction.editReply({ content: `✅ Ticket creado: ${result.channel}` });
    } catch (error) {
      console.error('Error al abrir ticket:', error);
      return interaction.editReply({ content: 'No pude crear el ticket. Comprueba que Bressh.bot tenga Manage Channels, View Channel y Manage Roles.' });
    }
  }

  if (interaction.isButton() && interaction.customId === 'ticket_close') {
    const channel = interaction.channel;
    const ownerId = channel?.topic?.startsWith('bressh-ticket:') ? channel.topic.slice('bressh-ticket:'.length) : null;
    const config = await readConfig();
    const settings = ticketSettings(config, interaction.guild.id);
    if (!ownerId || (!isTicketStaff(interaction.member, settings) && interaction.user.id !== ownerId)) {
      await interaction.reply({ content: 'Solo el creador del ticket o el equipo de soporte puede cerrarlo.', ephemeral: true });
      return;
    }
    await interaction.reply({ content: '🔒 Ticket cerrado. Este canal se eliminará en 3 segundos.', ephemeral: true });
    await ticketLog(interaction.guild, settings, 'Ticket cerrado', [
      { name: 'Cerrado por', value: `${interaction.user.tag} (${interaction.user.id})` },
      { name: 'Canal', value: `${channel}` },
    ]);
    setTimeout(() => channel.delete('Bressh.bot: ticket cerrado').catch(() => null), 3000);
    return;
  }

  if (interaction.isButton() && interaction.customId.startsWith('giveaway_join:')) {
    const messageId = interaction.customId.slice('giveaway_join:'.length);
    const giveaway = activeGiveaways.get(messageId);
    if (!giveaway) {
      await interaction.reply({ content: 'Este sorteo ya terminó.', ephemeral: true });
      return;
    }
    if (interaction.user.bot || !interaction.member) {
      await interaction.reply({ content: 'Los bots y usuarios que no sean miembros del servidor no pueden participar.', ephemeral: true });
      return;
    }
    const joined = giveaway.participants.has(interaction.user.id);
    if (joined) giveaway.participants.delete(interaction.user.id);
    else giveaway.participants.add(interaction.user.id);
    await interaction.reply({ content: joined ? 'Saliste del sorteo.' : 'Ya estás participando en el sorteo.', ephemeral: true });
    await interaction.message.edit({ embeds: [giveawayEmbed(giveaway)], components: [giveawayRow(messageId)] }).catch(() => null);
    return;
  }

  if (interaction.isButton() && interaction.customId === 'cookie_game_button') {
    if (finishedCookieGames.has(interaction.message.id)) {
      await interaction.reply({ content: 'Ya hay un ganador: la primera pulsación fue la válida.', ephemeral: true });
      return;
    }
    await interaction.deferUpdate();
    const blacklistRole = await getBlacklistRole(interaction.guild);
    if (blacklistRole && interaction.member.roles.cache.has(blacklistRole.id)) {
      return;
    }
    const claim = await claimCookieGame(interaction.message.id);
    if (!claim.claimed || activeCookieGames.has(interaction.message.id)) {
      return;
    }
    activeCookieGames.add(interaction.message.id);
    finishedCookieGames.add(interaction.message.id);
    try {
      await interaction.message.edit({ content: `<@${interaction.user.id}> fue el primero en canjear la galleta. 🍪\nSé rápido que todos.`, components: [cookieRow({ disabled: true, winner: true })] });
    } finally {
      activeCookieGames.delete(interaction.message.id);
      await finishCookieGame(claim.lockPath, interaction.user.id);
    }
    return;
  }

  if (!interaction.isChatInputCommand()) return;

  try {
    const isCookieGame = interaction.commandName === 'cookie' && interaction.options.getSubcommand() === 'game';
    if (!isCookieGame) await interaction.deferReply();

    if (interaction.commandName === 'ping') {
      return interaction.editReply({ content: `Pong. Latencia: ${client.ws.ping} ms` });
    }

    if (interaction.commandName === 'userinfo') {
      const user = interaction.options.getUser('usuario', true);
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!member) return replyError(interaction, 'ese usuario no es un miembro del servidor.');
      return interaction.editReply({ embeds: [userInfoEmbed(member)] });
    }

    if (interaction.commandName === 'serverinfo') {
      return interaction.editReply({ embeds: [await serverInfoEmbed(interaction.guild)] });
    }

    if (interaction.commandName === 'bienvenida') {
      const canConfigure = interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)
        || interaction.user.id === interaction.guild.ownerId;
      if (!canConfigure) return replyError(interaction, 'solo el dueño o alguien con Manage Server puede configurarla.');
      const message = interaction.options.getString('mensaje', true).trim();
      const channel = interaction.options.getChannel('canal') || interaction.channel;
      if (!channel?.isTextBased() || !channel.isSendable()) return replyError(interaction, 'selecciona un canal de texto donde Bressh.bot pueda enviar mensajes.');
      const botMember = interaction.guild.members.me || await interaction.guild.members.fetchMe().catch(() => null);
      if (!botMember || !channel.permissionsFor(botMember)?.has(PermissionsBitField.Flags.SendMessages)) {
        return replyError(interaction, `no tengo permiso para enviar mensajes en ${channel}.`);
      }
      const config = await readConfig();
      config[interaction.guild.id] = {
        ...(config[interaction.guild.id] || {}),
        welcome: {
          channelId: channel.id,
          message,
          sign: interaction.options.getString('signo') === '!' ? '!' : '',
          image: interaction.options.getBoolean('imagen') ?? false,
          emoji: interaction.options.getString('emoji')?.trim() || '',
        },
      };
      await writeConfig(config);
      return interaction.editReply({ content: `✅ Bienvenida configurada en ${channel}. Usa \'{usuario}\' donde quieras repetir la mención; el mensaje se enviará al entrar cada miembro nuevo.` });
    }

    if (interaction.commandName === 'anuncio') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const message = interaction.options.getString('mensaje', true).trim();
      const announcement = new EmbedBuilder()
        .setColor(0x20b8e8)
        .setTitle('📢 Anuncio importante')
        .setDescription(message)
        .setFooter({ text: 'Bressh.bot • anuncio oficial' })
        .setTimestamp();
      const icon = interaction.guild.iconURL({ size: 128 });
      if (icon) announcement.setAuthor({ name: interaction.guild.name, iconURL: icon });
      await interaction.channel.send({ embeds: [announcement] });
      return interaction.editReply({ content: '✅ Anuncio publicado correctamente.' });
    }

    if (interaction.commandName === 'button') {
      const message = interaction.options.getString('mensaje')?.trim() || '';
      const instruction = `${message ? `${message}\n\n` : ''}Presiona el botón celeste con este emoji 🎉 para saber si es sí o no.`;
      await interaction.editReply({ content: instruction });
      const response = await interaction.fetchReply();
      activeRandomButtons.set(response.id, { message, finished: false });
      return interaction.editReply({ content: instruction, components: [randomButtonRow(response.id)] });
    }

    if (interaction.commandName === 'kiss' || interaction.commandName === 'slap') {
      const type = interaction.commandName;
      const target = interaction.options.getUser('usuario', true);
      const actor = interaction.user;
      const embed = socialInteractionEmbed(type, actor, target);
      await interaction.editReply({ embeds: [embed] });
      const response = await interaction.fetchReply();
      pendingSocialInteractions.set(response.id, { type, actorId: actor.id, targetId: target.id });
      return interaction.editReply({ embeds: [embed], components: [socialInteractionRow(type, response.id)] });
    }

    if (interaction.commandName === 'avatar') {
      const requestedUser = interaction.options.getUser('usuario');
      let selectedUser = requestedUser;
      if (!selectedUser) {
        const members = [...interaction.guild.members.cache.values()].filter((member) => !member.user.bot);
        selectedUser = (members[Math.floor(Math.random() * members.length)] || interaction.member).user;
      }
      return interaction.editReply({ embeds: [await avatarEmbed(selectedUser, !requestedUser)] });
    }

    if (interaction.commandName === 'invite') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const user = interaction.options.getUser('usuario', true);
      try {
        const invites = await interaction.guild.invites.fetch();
        const total = invites.filter((invite) => invite.inviter?.id === user.id).reduce((sum, invite) => sum + (invite.uses || 0), 0);
        return interaction.editReply({ embeds: [new EmbedBuilder()
          .setColor(0x20b8e8)
          .setTitle(`Invitaciones de ${user.tag}`)
          .setThumbnail(user.displayAvatarURL({ size: 256 }))
          .setDescription(`${user} ha invitado aproximadamente a **${total}** persona(s) usando invitaciones que siguen disponibles.`)
          .setFooter({ text: 'Bressh.bot • contador de invitaciones' })] });
      } catch (error) {
        console.error('Error al consultar invitaciones:', error);
        return replyError(interaction, 'no pude consultar las invitaciones. Bressh.bot necesita Manage Server o Manage Channels y acceso al servidor.');
      }
    }

    if (interaction.commandName === 'antiraid') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const enabled = interaction.options.getString('accion', true) === 'on';
      const config = await readConfig();
      config[interaction.guild.id] = { ...(config[interaction.guild.id] || {}), antiRaid: enabled };
      await writeConfig(config);
      return interaction.editReply({ content: enabled
        ? '🛡️ Anti-Raid activado: se eliminarán enlaces, invitaciones, palabras bloqueadas y spam repetido; las entradas masivas sospechosas serán expulsadas.'
        : '🛡️ Anti-Raid desactivado.' });
    }

    if (interaction.commandName === 'antilink') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const enabled = interaction.options.getString('accion', true) === 'on';
      const config = await readConfig();
      config[interaction.guild.id] = { ...(config[interaction.guild.id] || {}), antiLink: enabled };
      await writeConfig(config);
      return interaction.editReply({ content: enabled
        ? '🔗 AntiLink activado: se eliminará cualquier enlace web o invitación de Discord y la acción quedará registrada en auditoría.'
        : '🔗 AntiLink desactivado.' });
    }

    if (interaction.commandName === 'anti_insulto') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const enabled = interaction.options.getString('accion', true) === 'on';
      const config = await readConfig();
      config[interaction.guild.id] = { ...(config[interaction.guild.id] || {}), antiInsult: enabled };
      await writeConfig(config);
      return interaction.editReply({ content: enabled
        ? '🛑 Anti-insulto activado: se borrará y registrará el lenguaje no adecuado.'
        : '🛑 Anti-insulto desactivado.' });
    }

    if (interaction.commandName === 'bloquear_palabra') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const word = interaction.options.getString('palabra', true).trim().toLowerCase();
      const config = await readConfig();
      const guildConfig = config[interaction.guild.id] || {};
      const blockedWords = [...new Set([...(guildConfig.blockedWords || []), word])];
      config[interaction.guild.id] = { ...guildConfig, blockedWords };
      await writeConfig(config);
      return interaction.editReply({ content: `✅ Añadido al filtro: **${word}**. Palabras bloqueadas: **${blockedWords.length}**.` });
    }

    if (interaction.commandName === 'lista_negra') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const config = await readConfig();
      const words = config[interaction.guild.id]?.blockedWords || [];
      return interaction.editReply({ content: words.length ? `🚫 Palabras bloqueadas (${words.length}):\n${limitText(words.map((word, index) => `${index + 1}. ${word}`).join('\n'), 1900)}` : '✅ No hay palabras bloqueadas en este servidor.' });
    }

    if (interaction.commandName === 'unbloqueopalabra') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const word = interaction.options.getString('palabra', true).trim().toLowerCase();
      const config = await readConfig();
      const guildConfig = config[interaction.guild.id] || {};
      const currentWords = guildConfig.blockedWords || [];
      const blockedWords = currentWords.filter((blockedWord) => blockedWord !== word);
      if (blockedWords.length === currentWords.length) return interaction.editReply({ content: `ℹ️ La palabra **${word}** no estaba bloqueada.` });
      config[interaction.guild.id] = { ...guildConfig, blockedWords };
      await writeConfig(config);
      return interaction.editReply({ content: `✅ Palabra desbloqueada: **${word}**. Ya no será eliminada por el filtro.` });
    }

    if (interaction.commandName === 'ban') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.BanMembers)) return replyError(interaction, 'necesitas el permiso Ban Members.');
      const user = interaction.options.getUser('usuario', true);
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (member && !member.bannable) return replyError(interaction, 'mi rango no puede banear a ese miembro.');
      const reason = interaction.options.getString('motivo') || `Acción ejecutada por ${interaction.user.tag}`;
      await interaction.guild.members.ban(user.id, { reason });
      queueLog(interaction.guild, 'Miembro baneado', 0xdc2626, [
        { name: 'Usuario', value: `${user.tag} (${user.id})` },
        { name: 'Moderador', value: `${interaction.user.tag} (${interaction.user.id})` },
        { name: 'Motivo', value: reason },
      ]);
      return interaction.editReply({ content: `⛔ ${user.tag} ha sido baneado.\nMotivo: ${reason}` });
    }

    if (interaction.commandName === 'kick') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.KickMembers)) return replyError(interaction, 'necesitas el permiso Kick Members.');
      const user = interaction.options.getUser('usuario', true);
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!member) return replyError(interaction, 'ese usuario no es un miembro del servidor.');
      if (!member.kickable) return replyError(interaction, 'mi rango no puede expulsar a ese miembro. Coloca el rol de Bressh.bot por encima.');
      const reason = interaction.options.getString('motivo') || `Acción ejecutada por ${interaction.user.tag}`;
      await member.kick(reason);
      queueLog(interaction.guild, 'Miembro expulsado', 0xf97316, [
        { name: 'Usuario', value: `${user.tag} (${user.id})` },
        { name: 'Moderador', value: `${interaction.user.tag} (${interaction.user.id})` },
        { name: 'Motivo', value: reason },
      ]);
      return interaction.editReply({ content: `👢 ${user.tag} ha sido expulsado.\nMotivo: ${reason}` });
    }

    if (interaction.commandName === 'warn') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ModerateMembers)) return replyError(interaction, 'necesitas el permiso Moderate Members.');
      const user = interaction.options.getUser('usuario', true);
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      const threshold = interaction.options.getInteger('avisos', true);
      const action = interaction.options.getString('accion', true);
      if (!member) return replyError(interaction, 'ese usuario no es un miembro del servidor.');
      if (member.id === interaction.user.id) return replyError(interaction, 'no puedes advertirte a ti mismo.');
      const reason = interaction.options.getString('motivo')?.trim() || `Advertencia aplicada por ${interaction.user.tag}`;
      const count = await addWarning(interaction.guild.id, member.id, threshold, action, reason);
      if (count < threshold) {
        queueLog(interaction.guild, 'Advertencia añadida', 0xf59e0b, [
          { name: 'Usuario', value: `${user.tag} (${user.id})` },
          { name: 'Moderador', value: `${interaction.user.tag} (${interaction.user.id})` },
          { name: 'Progreso', value: `${count}/${threshold}` },
          { name: 'Motivo', value: reason },
        ]);
        return interaction.editReply({ content: `⚠️ ${user.tag} recibió una advertencia (**${count}/${threshold}**). Acción al llegar al límite: **${warningActionLabels[action]}**.` });
      }
      const result = await applyWarningAction(interaction.guild, member, action, reason);
      await clearWarnings(interaction.guild.id, member.id);
      queueLog(interaction.guild, `Advertencias: ${result}`, 0xdc2626, [
        { name: 'Usuario', value: `${user.tag} (${user.id})` },
        { name: 'Moderador', value: `${interaction.user.tag} (${interaction.user.id})` },
        { name: 'Motivo', value: reason },
      ]);
      return interaction.editReply({ content: `⚠️ ${user.tag} alcanzó **${threshold}/${threshold}** advertencias y fue **${result}**.` });
    }

    if (interaction.commandName === 'afk') {
      const state = { since: Date.now(), reason: afkReason(interaction.options.getString('motivo')) };
      afkUsers.set(afkKey(interaction.guild.id, interaction.user.id), state);
      void saveAfkState(interaction.guild.id, interaction.user.id, state).catch((error) => console.error('No se pudo guardar AFK:', error.message));
      return interaction.editReply({ content: `<@${interaction.user.id}> ahora está afk.\nMotivo: ${state.reason}` });
    }

    if (interaction.commandName === 'purge') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageMessages)) return replyError(interaction, 'necesitas el permiso Manage Messages.');
      const subcommand = interaction.options.getSubcommand(true);
      const channel = interaction.options.getChannel('canal', true);
      const amount = interaction.options.getInteger('cantidad', true);
      const targetUser = subcommand === 'miembro' ? interaction.options.getUser('usuario', true) : null;
      const deleted = await purgeMessages(channel, amount, new Set(), targetUser?.id || null);
      queueLog(interaction.guild, 'Mensajes eliminados', 0xef4444, [
        { name: 'Moderador', value: `${interaction.user.tag} (${interaction.user.id})` },
        { name: 'Canal', value: `${channel}` },
        ...(targetUser ? [{ name: 'Miembro', value: `${targetUser.tag} (${targetUser.id})` }] : []),
        { name: 'Cantidad', value: String(deleted) },
      ]);
      return interaction.editReply({ content: `🧹 Se eliminaron **${deleted}** mensaje(s) de ${targetUser ? `${targetUser}` : 'el canal'} ${channel}.` });
    }

    if (interaction.commandName === 'sorteo') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const duration = parseGiveawayDuration(interaction.options.getString('duracion', true));
      if (!duration) return replyError(interaction, 'la duración debe ser como `2m`, `4h` o `7d`, entre 1 minuto y 20 días.');
      const giveaway = {
        guildId: interaction.guild.id,
        channelId: interaction.channel.id,
        reward: interaction.options.getString('recompensa')?.trim() || 'Sin recompensa especificada',
        winnerLimit: interaction.options.getInteger('ganadores', true),
        endsAt: Date.now() + duration.milliseconds,
        participants: new Set(),
      };
      await interaction.editReply({ embeds: [giveawayEmbed(giveaway)] });
      const giveawayMessage = await interaction.fetchReply();
      giveaway.messageId = giveawayMessage.id;
      activeGiveaways.set(giveawayMessage.id, giveaway);
      await giveawayMessage.edit({ embeds: [giveawayEmbed(giveaway)], components: [giveawayRow(giveawayMessage.id)] });
      setTimeout(() => void finishGiveaway(giveawayMessage.id), duration.milliseconds).unref();
      return;
    }

    if (interaction.commandName === 'silence') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ModerateMembers)) return replyError(interaction, 'necesitas el permiso Moderate Members.');
      const user = interaction.options.getUser('usuario', true);
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!member) return replyError(interaction, 'ese usuario no es un miembro del servidor.');
      if (!member.moderatable) return replyError(interaction, 'mi rango no puede silenciar a ese miembro.');
      const minutes = interaction.options.getInteger('minutos', true);
      const reason = interaction.options.getString('motivo') || `Acción ejecutada por ${interaction.user.tag}`;
      await member.timeout(minutes * 60 * 1000, reason);
      queueLog(interaction.guild, 'Miembro silenciado', 0xeab308, [
        { name: 'Usuario', value: `${user.tag} (${user.id})` },
        { name: 'Moderador', value: `${interaction.user.tag} (${interaction.user.id})` },
        { name: 'Duración', value: `${minutes} minuto(s)` },
        { name: 'Motivo', value: reason },
      ]);
      return interaction.editReply({ content: `🔇 ${user.tag} ha sido silenciado durante ${minutes} minuto(s).\nMotivo: ${reason}` });
    }

    if (interaction.commandName === 'role') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageRoles)) return replyError(interaction, 'necesitas el permiso Manage Roles.');
      const member = await interaction.guild.members.fetch(interaction.options.getUser('usuario', true).id).catch(() => null);
      const role = interaction.options.getRole('rol', true);
      const action = interaction.options.getString('accion', true);
      if (!member) return replyError(interaction, 'ese usuario no es un miembro del servidor.');
      if (!canManageRole(interaction.guild, role)) return replyError(interaction, 'mi rango no puede gestionar ese rol. Coloca el rol de Bressh.bot por encima.');
      if (action === 'add') await member.roles.add(role, `Bressh.bot por ${interaction.user.tag}`);
      else await member.roles.remove(role, `Bressh.bot por ${interaction.user.tag}`);
      return interaction.editReply({ content: `${action === 'add' ? '✅ Rol añadido' : '✅ Rol quitado'}: ${role.name} → ${member.user.tag}` });
    }

    if (interaction.commandName === 'lock' || interaction.commandName === 'unlock') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageChannels)) return replyError(interaction, 'necesitas el permiso Manage Channels.');
      const channel = interaction.options.getChannel('canal', true);
      const locked = interaction.commandName === 'lock';
      await setChannelLock(channel, locked, interaction.user.tag);
      return interaction.editReply({ content: `${locked ? '🔒 Canal bloqueado' : '🔓 Canal desbloqueado'}: ${channel}` });
    }

    if (interaction.commandName === 'autorol') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const role = interaction.options.getRole('rol', true);
      if (!canManageRole(interaction.guild, role)) return replyError(interaction, 'mi rango no puede asignar ese rol. Coloca el rol de Bressh.bot por encima.');
      const config = await readConfig();
      config[interaction.guild.id] = { ...(config[interaction.guild.id] || {}), autorolId: role.id };
      await writeConfig(config);
      return interaction.editReply({ content: `✅ Autorol configurado: los nuevos miembros recibirán **${role.name}**.` });
    }

    if (interaction.commandName === 'blacklist' || interaction.commandName === 'unblacklist') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const botMember = interaction.guild.members.me;
      if (!botMember?.permissions.has(PermissionsBitField.Flags.ManageRoles)) return replyError(interaction, 'Bressh.bot necesita el permiso **Manage Roles**.');
      if (!botMember?.permissions.has(PermissionsBitField.Flags.ManageChannels)) return replyError(interaction, 'Bressh.bot necesita el permiso **Manage Channels**.');
      const member = await interaction.guild.members.fetch(interaction.options.getUser('usuario', true).id).catch(() => null);
      if (!member) return replyError(interaction, 'ese usuario no es un miembro del servidor.');
      if (member.id === interaction.user.id) return replyError(interaction, 'no puedes aplicarte esta acción a ti mismo.');
      const role = await getBlacklistRole(interaction.guild, interaction.commandName === 'blacklist');
      if (!role) return replyError(interaction, 'no existe el rol Blacklist.');
      const blocked = interaction.commandName === 'blacklist';
      await applyBlacklist(interaction.guild, member, role, blocked);
      queueLog(interaction.guild, blocked ? 'Miembro añadido a blacklist' : 'Miembro retirado de blacklist', blocked ? 0x111827 : 0x22c55e, [
        { name: 'Usuario', value: `${member.user.tag} (${member.id})` },
        { name: 'Moderador', value: `${interaction.user.tag} (${interaction.user.id})` },
      ]);
      return interaction.editReply({ content: blocked ? `🚫 ${member.user.tag} está en blacklist: no podrá participar en el servidor.` : `✅ Se quitó la blacklist a ${member.user.tag}.` });
    }

    if (interaction.commandName === 'ticketperm') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const subcommand = interaction.options.getSubcommand(true);
      const config = await readConfig();
      const guildConfig = config[interaction.guild.id] || {};
      const settings = { ...ticketSettings(config, interaction.guild.id), staffRoleIds: [...(ticketSettings(config, interaction.guild.id).staffRoleIds || [])] };
      if (subcommand === 'ver') {
        const category = settings.categoryId ? interaction.guild.channels.cache.get(settings.categoryId) : null;
        const staff = settings.staffRoleIds.map((roleId) => interaction.guild.roles.cache.get(roleId)).filter(Boolean);
        const logs = settings.ticketLogChannelId ? interaction.guild.channels.cache.get(settings.ticketLogChannelId) : null;
        return interaction.editReply({ embeds: [new EmbedBuilder()
          .setColor(0x20b8e8)
          .setTitle('Configuración de tickets')
          .addFields(
            { name: 'Categoría', value: category ? `${category}` : 'Sin elegir', inline: true },
            { name: 'Staff', value: staff.length ? staff.map((role) => `${role}`).join(' ') : 'Ninguno', inline: true },
            { name: 'Logs', value: logs ? `${logs}` : 'Sin elegir', inline: true },
          )] });
      }
      if (subcommand === 'agregar-rol' || subcommand === 'quitar-rol') {
        const role = interaction.options.getRole('rol', true);
        const adding = subcommand === 'agregar-rol';
        settings.staffRoleIds = adding
          ? [...new Set([...settings.staffRoleIds, role.id])]
          : settings.staffRoleIds.filter((roleId) => roleId !== role.id);
        config[interaction.guild.id] = { ...guildConfig, ticket: settings };
        await writeConfig(config);
        return interaction.editReply({ content: adding ? `✅ ${role} ahora puede ver y atender los tickets.` : `✅ ${role} ya no forma parte del staff de tickets.` });
      }
      if (subcommand === 'categoria') {
        const category = interaction.options.getChannel('categoria', true);
        settings.categoryId = category.id;
        config[interaction.guild.id] = { ...guildConfig, ticket: settings };
        await writeConfig(config);
        return interaction.editReply({ content: `✅ Los tickets se crearán en la categoría ${category}.` });
      }
      if (subcommand === 'logs') {
        const channel = interaction.options.getChannel('canal', true);
        settings.ticketLogChannelId = channel.id;
        config[interaction.guild.id] = { ...guildConfig, ticket: settings };
        await writeConfig(config);
        return interaction.editReply({ content: `✅ Los eventos de tickets se registrarán en ${channel}.` });
      }
    }

    if (interaction.commandName === 'ticketpanel') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const channel = interaction.options.getChannel('canal', true);
      const message = interaction.options.getString('mensaje', true);
      const config = await readConfig();
      const settings = ticketSettings(config, interaction.guild.id);
      if (!settings.categoryId) return replyError(interaction, 'configura primero la categoría con `/ticketperm categoria`.');
      if (!settings.staffRoleIds?.length) return replyError(interaction, 'configura primero un rol con `/ticketperm agregar-rol`.');
      const panel = await channel.send({ embeds: [ticketPanelEmbed(message)], components: [ticketButtonRow()] });
      return interaction.editReply({ content: `✅ Panel de tickets publicado en ${channel}.` });
    }

    if (interaction.commandName === 'setlog') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const selectedChannel = interaction.options.getChannel('canal');
      const botMember = interaction.guild.members.me;
      if (!botMember?.permissions.has(PermissionsBitField.Flags.ManageChannels)) return replyError(interaction, 'Bressh.bot necesita el permiso **Manage Channels** para crear o configurar el canal de auditoría.');
      const channel = selectedChannel || interaction.guild.channels.cache.find((candidate) => candidate.name === 'auditoria-logs' && candidate.type === ChannelType.GuildText) || await interaction.guild.channels.create({
        name: 'auditoria-logs',
        type: ChannelType.GuildText,
        reason: 'Bressh.bot: canal privado de auditoría',
        permissionOverwrites: [
          { id: interaction.guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] },
          { id: botMember.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.EmbedLinks, PermissionsBitField.Flags.ReadMessageHistory] },
        ],
      });
      const config = await readConfig();
      config[interaction.guild.id] = { ...(config[interaction.guild.id] || {}), logChannelId: channel.id };
      logChannelIds.set(interaction.guild.id, channel.id);
      await writeConfig(config);
      return interaction.editReply({ content: `✅ Canal de logs configurado: ${channel}.` });
    }

    if (interaction.commandName === 'unsetlog') {
      if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return replyError(interaction, 'necesitas el permiso Manage Server.');
      const config = await readConfig();
      config[interaction.guild.id] = { ...(config[interaction.guild.id] || {}) };
      delete config[interaction.guild.id].logChannelId;
      logChannelIds.delete(interaction.guild.id);
      await writeConfig(config);
      return interaction.editReply({ content: '✅ Logs desactivados.' });
    }

    if (interaction.commandName === 'cookie' && interaction.options.getSubcommand() === 'game') {
      await interaction.deferReply();
      await interaction.editReply({ content: '🏁 Primero gana quien pulse la galleta.\nSé rápido que todos.\n\nLa galleta aparecerá al terminar la cuenta regresiva.', components: [] });
      for (let count = 5; count >= 1; count -= 1) {
        await wait(1000);
        await interaction.editReply({ content: `⏳ La galleta aparece en **${count}**...\nSé rápido que todos.`, components: [] });
      }
      return interaction.editReply({ content: '🍪 ¡Ya! El primero en pulsar gana.\nSé rápido que todos.', components: [cookieRow()] });
    }
  } catch (error) {
    console.error(`Error en /${interaction.commandName} [${error.code || 'sin código'}]:`, error);
    if (error.code === 10062 || error.code === 'INTERACTION_NOT_REPLIED') return;
    const message = error.code === 50013
      ? 'Bressh.bot no tiene permisos suficientes. Revisa **Manage Roles** y **Manage Channels**, y la posición de su rol.'
      : error.code === 50001
        ? 'Bressh.bot no tiene acceso a uno de los canales del servidor.'
        : 'No se pudo completar la acción. Revisa los permisos y vuelve a intentarlo.';
    if (interaction.deferred && !interaction.replied) await interaction.editReply({ content: message });
    else if (interaction.replied) await interaction.followUp({ content: message, ephemeral: true });
    else await interaction.reply({ content: message, ephemeral: true });
  }
});

process.on('unhandledRejection', (error) => console.error('Unhandled rejection:', error));
process.on('uncaughtException', (error) => console.error('Uncaught exception:', error));

client.login(DISCORD_TOKEN);
